<?php

$username = 'root';
$password = '';
$connection = new PDO( 'mysql:host=localhost;dbname=central_db', $username, $password );

?>