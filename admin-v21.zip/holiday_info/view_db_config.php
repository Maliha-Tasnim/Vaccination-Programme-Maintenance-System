<?php
define("HOST", "localhost");
define("USER", "root"); 
define("PASSWORD", "");
define("DATABASE", "central_db");
?>