<?php
    require_once ("db_connection.php");
    include_once ("mr_data_fetch.php");

    include_once ("mr_jan.php");
    include_once ("mr_feb.php");
    include_once ("mr_mar.php");
    include_once ("mr_apr.php");
    include_once ("mr_may.php");
    include_once ("mr_jun.php");
    include_once ("mr_jul.php");
    include_once ("mr_aug.php");
    include_once ("mr_sep.php");
    include_once ("mr_oct.php");
    include_once ("mr_nov.php");
    include_once ("mr_dec.php");
?>