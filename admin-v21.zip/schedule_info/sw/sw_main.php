<?php
    require_once ("db_connection.php");
    include_once ("sw_data_fetch.php");

    include_once ("sw_jan.php");
    include_once ("sw_feb.php");
    include_once ("sw_mar.php");
    include_once ("sw_apr.php");
    include_once ("sw_may.php");
    include_once ("sw_jun.php");
    include_once ("sw_jul.php");
    include_once ("sw_aug.php");
    include_once ("sw_sep.php");
    include_once ("sw_oct.php");
    include_once ("sw_nov.php");
    include_once ("sw_dec.php");
?>
           


<!-- include ("sw_schedule_creation.php");

 -->