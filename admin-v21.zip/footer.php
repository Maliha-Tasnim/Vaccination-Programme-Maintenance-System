
  <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>
  
  <script type="text/javascript" src="../libs/js/functions.js"></script>
  
  <!-- jQuery -->
  <script src="../libs/jquery/jquery.min.js"></script>

  <!-- Bootstrap Core JavaScript -->
  <script src="../libs/dist/bootstrap/js/bootstrap.min.js"></script>

  <!-- Metis Menu Plugin JavaScript -->
  <script src="../libs/dist/metisMenu/metisMenu.min.js"></script>

  <!-- Custom Theme JavaScript -->
  <script src="../libs/js/sb-admin-2.js"></script>

</body>
</html>

<?php if(isset($db)) { $db->db_disconnect(); } ?>